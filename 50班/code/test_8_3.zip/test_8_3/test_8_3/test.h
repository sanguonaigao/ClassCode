#define _CRT_SECURE_NO_WARNINGS 1

int g_val = 2018;
