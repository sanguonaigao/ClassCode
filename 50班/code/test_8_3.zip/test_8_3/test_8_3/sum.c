#define _CRT_SECURE_NO_WARNINGS 1
//#include "test.h"

int g_val = 2018;

