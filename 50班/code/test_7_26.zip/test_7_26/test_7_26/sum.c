#define _CRT_SECURE_NO_WARNINGS 1

////����
//char *p = "abcdef";


//char arr[] = "abcdef";